This method only works on Windows 32 or 64 bits systems.

STEPS
1. Make sure you have installed the latest version of the AWS CLI
   - https://aws.amazon.com/cli/
   - http://docs.aws.amazon.com/cli/latest/userguide/installing.html
2. Install the Managed Cloud CLI by executing one of the following
   installers based on your Windows system:
     32 Bits: AWS_Managed_Services_API_x86.msi
     64 Bits: AWS_Managed_Services_API_x64.msi
3. After the installation succeeds, you can find more information about
   the AWS Managed Services APIs using:
    aws amscm help
    aws amsskms help